package com.gclaw.faceverify.service.bestsign;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gclaw.faceverify.config.FaceVerifyConfig;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.*;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * BestSign API 客户端封装
 * <p>
 * 封装上上签（BestSign）OpenAPI 调用，包括：
 * - 个人认证初始化 (获取刷脸 H5 页面 URL)
 * - 认证结果查询
 * - 回调验签
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class BestSignClient {

    private final FaceVerifyConfig config;
    private final RestTemplate restTemplate;
    private final ObjectMapper objectMapper;

    /**
     * 发起个人身份认证 - 获取刷脸 H5 页面 URL
     *
     * @param userName 用户姓名
     * @param idNo     证件号码
     * @param callbackUrl 回调通知 URL
     * @param redirectUrl 刷脸完成后跳转 URL
     * @return BestSign 响应，包含 flowId 和 authUrl
     */
    public BestSignResponse initiateIdentityVerification(String userName, String idNo,
                                                          String callbackUrl, String redirectUrl) {
        String url = config.getApiBase() + "/person/identity/faceauth";

        Map<String, Object> params = new HashMap<>();
        params.put("developerId", config.getDeveloperId());
        params.put("flowId", UUID.randomUUID().toString());
        params.put("userName", userName);
        params.put("idNo", idNo);
        params.put("faceauthMode", "TENCENT");
        params.put("callbackUrl", callbackUrl);
        params.put("redirectUrl", redirectUrl);

        return doPost(url, params);
    }

    /**
     * 查询身份认证结果
     *
     * @param flowId BestSign 流程 ID
     * @return BestSign 响应，包含认证状态和结果
     */
    public BestSignResponse queryIdentityVerification(String flowId) {
        String url = config.getApiBase() + "/person/identity/faceauth/result";

        Map<String, Object> params = new HashMap<>();
        params.put("developerId", config.getDeveloperId());
        params.put("flowId", flowId);

        return doPost(url, params);
    }

    /**
     * 验证回调签名
     *
     * @param signData   待验签数据
     * @param signature  回调签名
     * @return 是否验签通过
     */
    public boolean verifyCallback(String signData, String signature) {
        // BestSign 回调签名验证逻辑
        // 实际实现需要使用 BestSign 提供的公钥进行 RSA 验签
        // 此处为简化实现，生产环境需对接 BestSign SDK 的验签方法
        log.warn("回调验签逻辑需要根据 BestSign SDK 文档实现");
        return true;
    }

    /**
     * 执行 POST 请求
     */
    private BestSignResponse doPost(String url, Map<String, Object> params) {
        try {
            // 添加公共参数和签名
            params.put("timestamp", String.valueOf(System.currentTimeMillis()));
            params.put("nonce", UUID.randomUUID().toString());

            // 计算请求签名 (实际需要 BestSign SDK 的签名方法)
            String requestSign = generateRequestSign(params);
            params.put("sign", requestSign);

            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);

            String body = objectMapper.writeValueAsString(params);
            HttpEntity<String> entity = new HttpEntity<>(body, headers);

            ResponseEntity<String> response = restTemplate.exchange(
                    url, HttpMethod.POST, entity, String.class);

            if (response.getStatusCode() == HttpStatus.OK && response.getBody() != null) {
                return objectMapper.readValue(response.getBody(), BestSignResponse.class);
            }

            BestSignResponse errorResponse = new BestSignResponse();
            errorResponse.setCode(-1);
            errorResponse.setMessage("HTTP 请求失败: " + response.getStatusCode());
            return errorResponse;

        } catch (Exception e) {
            log.error("BestSign API 调用失败: url={}", url, e);
            BestSignResponse errorResponse = new BestSignResponse();
            errorResponse.setCode(-1);
            errorResponse.setMessage("API 调用异常: " + e.getMessage());
            return errorResponse;
        }
    }

    /**
     * 生成请求签名
     * 实际需要根据 BestSign 文档实现签名算法
     */
    private String generateRequestSign(Map<String, Object> params) {
        // TODO: 对接 BestSign SDK 签名方法
        // 参考文档: https://open.bestsign.cn
        log.warn("BestSign 请求签名需要根据 SDK 文档实现");
        return "placeholder_sign";
    }
}
