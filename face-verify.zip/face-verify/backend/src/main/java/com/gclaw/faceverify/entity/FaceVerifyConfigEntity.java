package com.gclaw.faceverify.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;

import java.time.LocalDateTime;

/**
 * 人脸验证操作配置实体
 */
@Data
@TableName("face_verify_config")
public class FaceVerifyConfigEntity {

    @TableId(type = IdType.AUTO)
    private Long id;

    /**
     * 操作类型编码
     */
    private String operationType;

    /**
     * 操作显示名称
     */
    private String operationName;

    /**
     * 是否启用人脸验证
     */
    private Boolean enabled;

    /**
     * 刷脸方式: ZHIMACREDIT/TENCENT/ESIGN
     */
    private String faceauthMode;

    /**
     * 验证超时秒数
     */
    private Integer timeoutSeconds;

    /**
     * 最大重试次数
     */
    private Integer maxRetry;

    /**
     * 说明
     */
    private String description;

    /**
     * 逻辑删除
     */
    @TableLogic
    private Integer isDeleted;

    private LocalDateTime createdAt;

    private LocalDateTime updatedAt;
}
