package com.gclaw.faceverify.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.gclaw.faceverify.entity.FaceVerifyRecordEntity;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface FaceVerifyRecordMapper extends BaseMapper<FaceVerifyRecordEntity> {
}
