package com.gclaw.faceverify.service.bestsign;

import lombok.Data;

import java.util.Map;

/**
 * BestSign API 响应封装
 */
@Data
public class BestSignResponse {

    /**
     * 响应码 (0 表示成功)
     */
    private int code;

    /**
     * 响应消息
     */
    private String message;

    /**
     * 响应数据
     */
    private Map<String, Object> data;

    /**
     * 是否成功
     */
    public boolean isSuccess() {
        return code == 0;
    }

    /**
     * 获取数据中的字符串字段
     */
    public String getString(String key) {
        if (data == null) return null;
        Object value = data.get(key);
        return value != null ? value.toString() : null;
    }
}
