package com.gclaw.faceverify.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

/**
 * 人脸验证配置类 - BestSign API 密钥等
 */
@Data
@Configuration
@ConfigurationProperties(prefix = "face-verify.bestsign")
public class FaceVerifyConfig {

    /**
     * BestSign 开发者 ID
     */
    private String developerId;

    /**
     * BestSign 私钥 (p12 格式路径或内容)
     */
    private String privateKey;

    /**
     * BestSign API 基础地址
     */
    private String apiBase = "https://open.bestsign.cn/openapi";

    /**
     * Token 签发密钥 (HMAC-SHA256)
     */
    private String tokenSecret;

    /**
     * Token 有效期 (分钟)
     */
    private int tokenExpireMinutes = 5;

    /**
     * 回调通知 URL (BestSign 验证完成后回调)
     */
    private String callbackUrl;

    /**
     * 刷脸完成后的跳转 URL
     */
    private String redirectUrl;
}
