package com.gclaw.faceverify.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.gclaw.faceverify.config.FaceVerifyConfig;
import com.gclaw.faceverify.dto.*;
import com.gclaw.faceverify.entity.FaceVerifyConfigEntity;
import com.gclaw.faceverify.entity.FaceVerifyRecordEntity;
import com.gclaw.faceverify.mapper.FaceVerifyConfigMapper;
import com.gclaw.faceverify.mapper.FaceVerifyRecordMapper;
import com.gclaw.faceverify.service.FaceVerifyService;
import com.gclaw.faceverify.service.bestsign.BestSignClient;
import com.gclaw.faceverify.service.bestsign.BestSignResponse;
import com.gclaw.faceverify.util.VerificationTokenUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.UUID;

/**
 * 人脸验证核心业务逻辑实现
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class FaceVerifyServiceImpl implements FaceVerifyService {

    private final FaceVerifyConfigMapper configMapper;
    private final FaceVerifyRecordMapper recordMapper;
    private final BestSignClient bestSignClient;
    private final VerificationTokenUtil tokenUtil;
    private final FaceVerifyConfig faceVerifyConfig;

    private static final DateTimeFormatter FORMATTER = DateTimeFormatter.ISO_LOCAL_DATE_TIME;

    @Override
    public FaceVerifyCheckDTO check(String operationType) {
        FaceVerifyConfigEntity config = getConfig(operationType);
        if (config == null || !config.getEnabled()) {
            return FaceVerifyCheckDTO.notRequired(operationType);
        }
        return FaceVerifyCheckDTO.required(
                operationType,
                config.getOperationName(),
                config.getFaceauthMode(),
                config.getMaxRetry()
        );
    }

    @Override
    public boolean isRequired(String operationType) {
        FaceVerifyConfigEntity config = getConfig(operationType);
        return config != null && config.getEnabled();
    }

    @Override
    public FaceVerifyInitDTO.Response initiate(FaceVerifyInitDTO.Request request) {
        // 1. 校验操作类型是否启用人脸验证
        FaceVerifyConfigEntity config = getConfig(request.getOperationType());
        if (config == null || !config.getEnabled()) {
            throw new RuntimeException("该操作未启用人脸验证: " + request.getOperationType());
        }

        // 2. 检查是否有进行中的验证（防重复）
        FaceVerifyRecordEntity existing = getPendingRecord(request.getUserId(), request.getOperationType());
        if (existing != null) {
            // 已有进行中的验证，直接返回
            FaceVerifyInitDTO.Response response = new FaceVerifyInitDTO.Response();
            response.setVerificationId(existing.getVerificationId());
            response.setAuthUrl(existing.getFlowId()); // 前端可根据 verificationId 重新查询
            response.setExpireAt(existing.getCreatedAt()
                    .plusSeconds(config.getTimeoutSeconds())
                    .format(FORMATTER));
            return response;
        }

        // 3. 调用 BestSign API 获取刷脸 URL
        BestSignResponse bsResponse = bestSignClient.initiateIdentityVerification(
                request.getUserName(),
                request.getIdNo(),
                faceVerifyConfig.getCallbackUrl(),
                faceVerifyConfig.getRedirectUrl()
        );

        if (!bsResponse.isSuccess()) {
            throw new RuntimeException("BestSign 验证发起失败: " + bsResponse.getMessage());
        }

        String flowId = bsResponse.getString("flowId");
        String authUrl = bsResponse.getString("authUrl");

        // 4. 创建验证记录
        String verificationId = UUID.randomUUID().toString().replace("-", "");
        FaceVerifyRecordEntity record = new FaceVerifyRecordEntity();
        record.setVerificationId(verificationId);
        record.setFlowId(flowId);
        record.setOperationType(request.getOperationType());
        record.setBusinessId(request.getBusinessId());
        record.setBusinessNo(request.getBusinessNo());
        record.setUserId(request.getUserId());
        record.setUserName(request.getUserName());
        record.setIdNo(encryptIdNo(request.getIdNo()));
        record.setStatus("in_progress");
        record.setTokenConsumed(false);
        recordMapper.insert(record);

        // 5. 返回结果
        FaceVerifyInitDTO.Response response = new FaceVerifyInitDTO.Response();
        response.setVerificationId(verificationId);
        response.setAuthUrl(authUrl);
        response.setExpireAt(LocalDateTime.now()
                .plusSeconds(config.getTimeoutSeconds())
                .format(FORMATTER));
        return response;
    }

    @Override
    public FaceVerifyResultDTO result(String verificationId) {
        // 1. 查询验证记录
        FaceVerifyRecordEntity record = getRecordByVerificationId(verificationId);
        if (record == null) {
            throw new RuntimeException("验证记录不存在: " + verificationId);
        }

        FaceVerifyResultDTO result = new FaceVerifyResultDTO();
        result.setVerificationId(verificationId);

        // 2. 若仍为进行中状态，主动查询 BestSign
        if ("in_progress".equals(record.getStatus()) || "pending".equals(record.getStatus())) {
            BestSignResponse bsResponse = bestSignClient.queryIdentityVerification(record.getFlowId());
            if (bsResponse.isSuccess()) {
                String bsStatus = bsResponse.getString("status");
                if ("passed".equals(bsStatus)) {
                    updateRecordPassed(record);
                } else if ("failed".equals(bsStatus)) {
                    updateRecordFailed(record, bsResponse.getString("errorMessage"));
                }
                // 刷新记录
                record = getRecordByVerificationId(verificationId);
            }
        }

        // 3. 构建结果
        result.setStatus(record.getStatus());
        result.setErrorMessage(record.getErrorMessage());

        // 4. 如果验证通过且未签发 token，签发一次性 token
        if ("passed".equals(record.getStatus())) {
            if (record.getVerificationToken() == null) {
                String token = tokenUtil.issueToken(verificationId, record.getOperationType());
                LocalDateTime expireAt = tokenUtil.calculateExpireAt();

                record.setVerificationToken(token);
                record.setTokenExpireAt(expireAt);
                recordMapper.updateById(record);
            }

            result.setVerificationToken(record.getVerificationToken());
            if (record.getTokenExpireAt() != null) {
                result.setTokenExpireAt(record.getTokenExpireAt().format(FORMATTER));
            }
        }

        return result;
    }

    @Override
    public void handleCallback(String flowId, String status, String errorMsg) {
        FaceVerifyRecordEntity record = getRecordByFlowId(flowId);
        if (record == null) {
            log.warn("回调通知: 未找到 flowId={} 的验证记录", flowId);
            return;
        }

        if ("passed".equals(status)) {
            updateRecordPassed(record);
        } else if ("failed".equals(status)) {
            updateRecordFailed(record, errorMsg);
        }
    }

    @Override
    public boolean consumeToken(String verificationId) {
        FaceVerifyRecordEntity record = getRecordByVerificationId(verificationId);
        if (record == null) {
            return false;
        }

        if (record.getTokenConsumed()) {
            log.warn("Token 已被消费: verificationId={}", verificationId);
            return false;
        }

        if (record.getTokenExpireAt() != null && record.getTokenExpireAt().isBefore(LocalDateTime.now())) {
            log.warn("Token 已过期: verificationId={}", verificationId);
            return false;
        }

        record.setTokenConsumed(true);
        recordMapper.updateById(record);
        return true;
    }

    // ========== 私有方法 ==========

    private FaceVerifyConfigEntity getConfig(String operationType) {
        return configMapper.selectOne(
                new LambdaQueryWrapper<FaceVerifyConfigEntity>()
                        .eq(FaceVerifyConfigEntity::getOperationType, operationType)
        );
    }

    private FaceVerifyRecordEntity getPendingRecord(String userId, String operationType) {
        return recordMapper.selectOne(
                new LambdaQueryWrapper<FaceVerifyRecordEntity>()
                        .eq(FaceVerifyRecordEntity::getUserId, userId)
                        .eq(FaceVerifyRecordEntity::getOperationType, operationType)
                        .in(FaceVerifyRecordEntity::getStatus, "pending", "in_progress")
                        .orderByDesc(FaceVerifyRecordEntity::getCreatedAt)
                        .last("LIMIT 1")
        );
    }

    private FaceVerifyRecordEntity getRecordByVerificationId(String verificationId) {
        return recordMapper.selectOne(
                new LambdaQueryWrapper<FaceVerifyRecordEntity>()
                        .eq(FaceVerifyRecordEntity::getVerificationId, verificationId)
        );
    }

    private FaceVerifyRecordEntity getRecordByFlowId(String flowId) {
        return recordMapper.selectOne(
                new LambdaQueryWrapper<FaceVerifyRecordEntity>()
                        .eq(FaceVerifyRecordEntity::getFlowId, flowId)
        );
    }

    private void updateRecordPassed(FaceVerifyRecordEntity record) {
        record.setStatus("passed");
        record.setCompletedAt(LocalDateTime.now());
        recordMapper.updateById(record);
        log.info("人脸验证通过: verificationId={}", record.getVerificationId());
    }

    private void updateRecordFailed(FaceVerifyRecordEntity record, String errorMsg) {
        record.setStatus("failed");
        record.setErrorMessage(errorMsg);
        record.setCompletedAt(LocalDateTime.now());
        recordMapper.updateById(record);
        log.warn("人脸验证失败: verificationId={}, reason={}", record.getVerificationId(), errorMsg);
    }

    /**
     * AES 加密证件号
     * 生产环境应使用独立的加密服务或工具类
     */
    private String encryptIdNo(String idNo) {
        // TODO: 对接 AES 加密工具
        return idNo;
    }
}
