package com.gclaw.faceverify.dto;

import lombok.Data;

/**
 * 检查操作是否需要人脸验证 - 响应
 */
@Data
public class FaceVerifyCheckDTO {

    /**
     * 操作类型
     */
    private String operationType;

    /**
     * 是否需要人脸验证
     */
    private Boolean required;

    /**
     * 操作显示名称
     */
    private String operationName;

    /**
     * 刷脸方式
     */
    private String faceauthMode;

    /**
     * 最大重试次数
     */
    private Integer maxRetry;

    public static FaceVerifyCheckDTO notRequired(String operationType) {
        FaceVerifyCheckDTO dto = new FaceVerifyCheckDTO();
        dto.setOperationType(operationType);
        dto.setRequired(false);
        return dto;
    }

    public static FaceVerifyCheckDTO required(String operationType, String operationName,
                                               String faceauthMode, Integer maxRetry) {
        FaceVerifyCheckDTO dto = new FaceVerifyCheckDTO();
        dto.setOperationType(operationType);
        dto.setRequired(true);
        dto.setOperationName(operationName);
        dto.setFaceauthMode(faceauthMode);
        dto.setMaxRetry(maxRetry);
        return dto;
    }
}
