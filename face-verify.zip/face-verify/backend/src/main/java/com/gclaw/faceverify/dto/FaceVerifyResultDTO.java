package com.gclaw.faceverify.dto;

import lombok.Data;

/**
 * 验证结果 - 响应
 */
@Data
public class FaceVerifyResultDTO {

    /**
     * 验证ID
     */
    private String verificationId;

    /**
     * 验证状态: pending/in_progress/passed/failed/expired
     */
    private String status;

    /**
     * 验证通过后签发的 token (仅在 passed 时返回)
     */
    private String verificationToken;

    /**
     * token 过期时间 (仅在 passed 时返回)
     */
    private String tokenExpireAt;

    /**
     * 失败原因
     */
    private String errorMessage;
}
