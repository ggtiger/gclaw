package com.gclaw.faceverify.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.gclaw.faceverify.entity.FaceVerifyConfigEntity;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface FaceVerifyConfigMapper extends BaseMapper<FaceVerifyConfigEntity> {
}
