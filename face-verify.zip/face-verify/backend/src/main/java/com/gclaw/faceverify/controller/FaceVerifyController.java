package com.gclaw.faceverify.controller;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.gclaw.faceverify.dto.*;
import com.gclaw.faceverify.entity.FaceVerifyConfigEntity;
import com.gclaw.faceverify.mapper.FaceVerifyConfigMapper;
import com.gclaw.faceverify.service.FaceVerifyService;
import com.gclaw.faceverify.util.VerificationTokenUtil;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * 人脸验证 REST 接口
 */
@RestController
@RequestMapping("/api/face-verify")
@RequiredArgsConstructor
public class FaceVerifyController {

    private final FaceVerifyService faceVerifyService;
    private final FaceVerifyConfigMapper configMapper;
    private final VerificationTokenUtil tokenUtil;

    /**
     * 检查操作是否需要人脸验证
     */
    @GetMapping("/check")
    public ResponseEntity<FaceVerifyCheckDTO> check(@RequestParam String operationType) {
        return ResponseEntity.ok(faceVerifyService.check(operationType));
    }

    /**
     * 发起人脸验证，返回刷脸 URL
     */
    @PostMapping("/initiate")
    public ResponseEntity<?> initiate(@RequestBody FaceVerifyInitDTO.Request request) {
        try {
            FaceVerifyInitDTO.Response response = faceVerifyService.initiate(request);
            return ResponseEntity.ok(response);
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(Map.of(
                    "error", e.getMessage()
            ));
        }
    }

    /**
     * 轮询验证结果
     */
    @GetMapping("/result")
    public ResponseEntity<?> result(@RequestParam String verificationId) {
        try {
            FaceVerifyResultDTO result = faceVerifyService.result(verificationId);
            return ResponseEntity.ok(result);
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(Map.of(
                    "error", e.getMessage()
            ));
        }
    }

    /**
     * BestSign 回调通知端点
     * BestSign 在验证完成后会调用此接口通知结果
     */
    @PostMapping("/callback")
    public ResponseEntity<String> callback(@RequestBody Map<String, String> payload) {
        String flowId = payload.get("flowId");
        String status = payload.get("status");
        String errorMsg = payload.get("errorMessage");

        try {
            faceVerifyService.handleCallback(flowId, status, errorMsg);
            return ResponseEntity.ok("OK");
        } catch (Exception e) {
            return ResponseEntity.internalServerError().body("FAIL");
        }
    }

    /**
     * 获取所有配置 (管理接口)
     */
    @GetMapping("/configs")
    public ResponseEntity<List<FaceVerifyConfigEntity>> getConfigs() {
        List<FaceVerifyConfigEntity> configs = configMapper.selectList(
                new LambdaQueryWrapper<FaceVerifyConfigEntity>()
                        .orderByAsc(FaceVerifyConfigEntity::getId)
        );
        return ResponseEntity.ok(configs);
    }

    /**
     * 更新配置 (管理接口)
     */
    @PutMapping("/config")
    public ResponseEntity<?> updateConfig(@RequestBody FaceVerifyConfigEntity config) {
        configMapper.updateById(config);
        return ResponseEntity.ok(Map.of("message", "配置更新成功"));
    }
}
