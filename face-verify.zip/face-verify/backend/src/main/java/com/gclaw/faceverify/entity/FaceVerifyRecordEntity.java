package com.gclaw.faceverify.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;

import java.time.LocalDateTime;

/**
 * 人脸验证记录实体
 */
@Data
@TableName("face_verify_record")
public class FaceVerifyRecordEntity {

    @TableId(type = IdType.AUTO)
    private Long id;

    /**
     * 验证唯一ID
     */
    private String verificationId;

    /**
     * BestSign流程ID
     */
    private String flowId;

    /**
     * 关联操作类型
     */
    private String operationType;

    /**
     * 业务ID
     */
    private String businessId;

    /**
     * 业务单号
     */
    private String businessNo;

    /**
     * 操作用户ID
     */
    private String userId;

    /**
     * 用户姓名
     */
    private String userName;

    /**
     * 证件号 (AES加密存储)
     */
    private String idNo;

    /**
     * 验证状态: pending/in_progress/passed/failed/expired
     */
    private String status;

    /**
     * 验证通过后签发的token
     */
    private String verificationToken;

    /**
     * token过期时间
     */
    private LocalDateTime tokenExpireAt;

    /**
     * token是否已消费 (一次性)
     */
    private Boolean tokenConsumed;

    /**
     * 失败原因
     */
    private String errorMessage;

    /**
     * 逻辑删除
     */
    @TableLogic
    private Integer isDeleted;

    private LocalDateTime createdAt;

    /**
     * 完成时间
     */
    private LocalDateTime completedAt;
}
