package com.gclaw.faceverify.dto;

import lombok.Data;

/**
 * 发起人脸验证 - 请求 & 响应
 */
public class FaceVerifyInitDTO {

    @Data
    public static class Request {
        /**
         * 操作类型
         */
        private String operationType;

        /**
         * 业务ID
         */
        private String businessId;

        /**
         * 业务单号
         */
        private String businessNo;

        /**
         * 用户ID
         */
        private String userId;

        /**
         * 用户姓名
         */
        private String userName;

        /**
         * 证件号 (前端传入明文，后端加密存储)
         */
        private String idNo;
    }

    @Data
    public static class Response {
        /**
         * 验证唯一ID
         */
        private String verificationId;

        /**
         * BestSign 刷脸 H5 页面 URL
         */
        private String authUrl;

        /**
         * 验证过期时间
         */
        private String expireAt;
    }
}
