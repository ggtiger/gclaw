package com.gclaw.faceverify.service;

import com.gclaw.faceverify.dto.*;
import com.gclaw.faceverify.util.VerificationTokenUtil;

/**
 * 人脸验证核心业务逻辑接口
 */
public interface FaceVerifyService {

    /**
     * 检查操作是否需要人脸验证
     *
     * @param operationType 操作类型
     * @return 检查结果
     */
    FaceVerifyCheckDTO check(String operationType);

    /**
     * 是否需要人脸验证 (供业务层快速判断)
     */
    boolean isRequired(String operationType);

    /**
     * 发起人脸验证
     *
     * @param request 发起验证请求
     * @return 刷脸页面 URL 等信息
     */
    FaceVerifyInitDTO.Response initiate(FaceVerifyInitDTO.Request request);

    /**
     * 查询验证结果 (前端轮询调用)
     *
     * @param verificationId 验证ID
     * @return 验证结果
     */
    FaceVerifyResultDTO result(String verificationId);

    /**
     * 处理 BestSign 回调通知
     *
     * @param flowId    流程ID
     * @param status    验证状态
     * @param errorMsg  错误信息 (失败时)
     */
    void handleCallback(String flowId, String status, String errorMsg);

    /**
     * 消费 Token (一次性，提交业务时调用)
     *
     * @param verificationId 验证ID
     * @return 是否消费成功
     */
    boolean consumeToken(String verificationId);
}
