package com.gclaw.faceverify.util;

import com.gclaw.faceverify.config.FaceVerifyConfig;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.Base64;

/**
 * 人脸验证 Token 签发与验证工具
 * <p>
 * 使用 HMAC-SHA256 签名，绑定 verificationId + operationType。
 * Token 格式: {verificationId}.{operationType}.{timestamp}.{nonce}.{signature}
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class VerificationTokenUtil {

    private static final String HMAC_ALGORITHM = "HmacSHA256";
    private static final DateTimeFormatter FORMATTER = DateTimeFormatter.ISO_LOCAL_DATE_TIME;
    private static final SecureRandom SECURE_RANDOM = new SecureRandom();

    private final FaceVerifyConfig config;

    /**
     * Token 验证结果
     */
    @Data
    public static class TokenValidationResult {
        private boolean valid;
        private String verificationId;
        private String operationType;
        private String errorMessage;

        public static TokenValidationResult success(String verificationId, String operationType) {
            TokenValidationResult result = new TokenValidationResult();
            result.setValid(true);
            result.setVerificationId(verificationId);
            result.setOperationType(operationType);
            return result;
        }

        public static TokenValidationResult fail(String errorMessage) {
            TokenValidationResult result = new TokenValidationResult();
            result.setValid(false);
            result.setErrorMessage(errorMessage);
            return result;
        }
    }

    /**
     * 签发 Token
     *
     * @param verificationId 验证ID
     * @param operationType  操作类型
     * @return 签发的 token 字符串
     */
    public String issueToken(String verificationId, String operationType) {
        long timestamp = LocalDateTime.now().toEpochSecond(ZoneOffset.UTC);
        String nonce = generateNonce();
        String payload = buildPayload(verificationId, operationType, timestamp, nonce);
        String signature = sign(payload);
        return payload + "." + signature;
    }

    /**
     * 计算 token 过期时间
     */
    public LocalDateTime calculateExpireAt() {
        return LocalDateTime.now().plusMinutes(config.getTokenExpireMinutes());
    }

    /**
     * 验证 Token
     *
     * @param token         待验证的 token
     * @param operationType 期望的操作类型
     * @return 验证结果
     */
    public TokenValidationResult validate(String token, String operationType) {
        if (token == null || token.isEmpty()) {
            return TokenValidationResult.fail("Token 不能为空");
        }

        String[] parts = token.split("\\.");
        if (parts.length != 5) {
            return TokenValidationResult.fail("Token 格式无效");
        }

        String verificationId = parts[0];
        String tokenOpType = parts[1];
        String timestampStr = parts[2];
        String nonce = parts[3];
        String providedSignature = parts[4];

        // 校验操作类型
        if (!operationType.equals(tokenOpType)) {
            return TokenValidationResult.fail("Token 操作类型不匹配");
        }

        // 校验时间戳
        long timestamp;
        try {
            timestamp = Long.parseLong(timestampStr);
        } catch (NumberFormatException e) {
            return TokenValidationResult.fail("Token 时间戳无效");
        }

        long now = LocalDateTime.now().toEpochSecond(ZoneOffset.UTC);
        long expireSeconds = config.getTokenExpireMinutes() * 60L;
        if (now - timestamp > expireSeconds) {
            return TokenValidationResult.fail("Token 已过期");
        }

        // 校验签名
        String payload = buildPayload(verificationId, tokenOpType, timestamp, nonce);
        String expectedSignature = sign(payload);
        if (!expectedSignature.equals(providedSignature)) {
            return TokenValidationResult.fail("Token 签名无效");
        }

        return TokenValidationResult.success(verificationId, tokenOpType);
    }

    /**
     * 构建 payload 字符串
     */
    private String buildPayload(String verificationId, String operationType,
                                long timestamp, String nonce) {
        return verificationId + "." + operationType + "." + timestamp + "." + nonce;
    }

    /**
     * HMAC-SHA256 签名
     */
    private String sign(String payload) {
        try {
            Mac mac = Mac.getInstance(HMAC_ALGORITHM);
            SecretKeySpec keySpec = new SecretKeySpec(
                    config.getTokenSecret().getBytes(StandardCharsets.UTF_8),
                    HMAC_ALGORITHM);
            mac.init(keySpec);
            byte[] hash = mac.doFinal(payload.getBytes(StandardCharsets.UTF_8));
            return Base64.getUrlEncoder().withoutPadding().encodeToString(hash);
        } catch (Exception e) {
            log.error("Token 签名失败", e);
            throw new RuntimeException("Token 签名失败", e);
        }
    }

    /**
     * 生成随机 nonce
     */
    private String generateNonce() {
        byte[] bytes = new byte[16];
        SECURE_RANDOM.nextBytes(bytes);
        return Base64.getUrlEncoder().withoutPadding().encodeToString(bytes);
    }
}
