/**
 * 人脸验证核心 Composable
 *
 * 使用方式:
 * ```typescript
 * const { submitWithVerify, visible, status, authUrl, errorMessage, cancelVerify } = useFaceVerify({
 *   operationType: 'contract_sign',
 *   onSuccess: (token) => { console.log('验证通过', token) }
 * })
 *
 * async function handleSubmit() {
 *   await submitWithVerify(async (verificationToken) => {
 *     await api.submit({ ...formData, verificationToken })
 *   })
 * }
 * ```
 */
import { ref, onUnmounted } from 'vue'
import type { VerifyStatus, UseFaceVerifyOptions, UseFaceVerifyReturn } from '../types/face-verify'
import { checkFaceVerify, initiateFaceVerify, getFaceVerifyResult } from '../api/face-verify'

/** 轮询间隔 (毫秒) */
const POLL_INTERVAL = 2000
/** 最大轮询次数 */
const MAX_POLL_COUNT = 90 // 180秒 / 2秒

/** useFaceVerify Composable 扩展选项 */
export interface UseFaceVerifyExtendedOptions extends UseFaceVerifyOptions {
  businessId?: string
  businessNo?: string
}

export function useFaceVerify(options: UseFaceVerifyExtendedOptions): UseFaceVerifyReturn {
  const { operationType, onSuccess, onFail, businessId, businessNo } = options

  const visible = ref(false)
  const status = ref<VerifyStatus>('idle')
  const authUrl = ref<string | null>(null)
  const errorMessage = ref<string | null>(null)

  let verificationId: string | null = null
  let pollTimer: ReturnType<typeof setInterval> | null = null
  let pollCount = 0

  /** 停止轮询 */
  function stopPolling() {
    if (pollTimer) {
      clearInterval(pollTimer)
      pollTimer = null
    }
  }

  /** 开始轮询验证结果 */
  function startPolling() {
    stopPolling()
    pollCount = 0
    status.value = 'polling'

    pollTimer = setInterval(async () => {
      pollCount++

      if (pollCount > MAX_POLL_COUNT) {
        stopPolling()
        status.value = 'expired'
        errorMessage.value = '验证超时，请重新发起验证'
        onFail?.(errorMessage.value)
        return
      }

      try {
        if (!verificationId) return

        const result = await getFaceVerifyResult(verificationId)

        if (result.status === 'passed') {
          stopPolling()
          status.value = 'passed'

          if (result.verificationToken) {
            onSuccess?.(result.verificationToken)
          }
        } else if (result.status === 'failed') {
          stopPolling()
          status.value = 'failed'
          errorMessage.value = result.errorMessage || '人脸验证失败'
          onFail?.(errorMessage.value!)
        }
        // 其他状态继续轮询 (pending, in_progress)
      } catch (e: any) {
        console.error('轮询验证结果失败:', e)
      }
    }, POLL_INTERVAL)
  }

  /** 包装提交操作，自动处理人脸验证拦截 */
  async function submitWithVerify(
    submitFn: (verificationToken?: string) => Promise<void>
  ): Promise<void> {
    try {
      // 1. 检查是否需要人脸验证
      status.value = 'checking'
      const checkResult = await checkFaceVerify(operationType)

      if (!checkResult.required) {
        // 不需要验证，直接执行提交
        await submitFn()
        return
      }

      // 2. 需要验证，发起验证流程
      status.value = 'loading'

      // 获取当前用户信息 (从业务上下文中获取)
      const userInfo = getUserInfo()

      const initResponse = await initiateFaceVerify({
        operationType,
        businessId,
        businessNo,
        userId: userInfo.userId,
        userName: userInfo.userName,
        idNo: userInfo.idNo,
      })

      verificationId = initResponse.verificationId
      authUrl.value = initResponse.authUrl
      visible.value = true
      status.value = 'in_progress'

      // 3. 等待验证完成的 Promise
      await new Promise<void>((resolve, reject) => {
        const originalOnSuccess = onSuccess
        const originalOnFail = onFail

        // 临时覆盖回调
        const wrappedOnSuccess = (token: string) => {
          originalOnSuccess?.(token)
          // 4. 验证通过，带 token 执行提交
          submitFn(token)
            .then(resolve)
            .catch(reject)
        }

        const wrappedOnFail = (error: string) => {
          originalOnFail?.(error)
          reject(new Error(error))
        }

        // 重新绑定回调
        // 使用轮询 + 事件驱动的方式
        startPollingWithCallbacks(wrappedOnSuccess, wrappedOnFail)
      })
    } catch (e: any) {
      status.value = 'error'
      errorMessage.value = e.message || '操作失败'
      throw e
    }
  }

  /** 带回调的轮询 */
  function startPollingWithCallbacks(
    resolveCallback: (token: string) => void,
    rejectCallback: (error: string) => void
  ) {
    stopPolling()
    pollCount = 0
    status.value = 'polling'

    pollTimer = setInterval(async () => {
      pollCount++

      if (pollCount > MAX_POLL_COUNT) {
        stopPolling()
        status.value = 'expired'
        errorMessage.value = '验证超时，请重新发起验证'
        rejectCallback(errorMessage.value)
        return
      }

      try {
        if (!verificationId) return

        const result = await getFaceVerifyResult(verificationId)

        if (result.status === 'passed') {
          stopPolling()
          status.value = 'passed'
          if (result.verificationToken) {
            resolveCallback(result.verificationToken)
          }
        } else if (result.status === 'failed') {
          stopPolling()
          status.value = 'failed'
          errorMessage.value = result.errorMessage || '人脸验证失败'
          rejectCallback(errorMessage.value)
        }
      } catch (e: any) {
        console.error('轮询验证结果失败:', e)
      }
    }, POLL_INTERVAL)
  }

  /** 取消验证 */
  function cancelVerify() {
    stopPolling()
    visible.value = false
    status.value = 'idle'
    authUrl.value = null
    errorMessage.value = null
    verificationId = null
  }

  /** 获取用户信息 (需要根据实际项目获取) */
  function getUserInfo() {
    // TODO: 从业务上下文/Store/Pinia 中获取当前登录用户信息
    return {
      userId: '',
      userName: '',
      idNo: '',
    }
  }

  // 组件卸载时清理轮询
  onUnmounted(() => {
    stopPolling()
  })

  return {
    visible,
    status,
    authUrl,
    errorMessage,
    submitWithVerify,
    cancelVerify,
  }
}
