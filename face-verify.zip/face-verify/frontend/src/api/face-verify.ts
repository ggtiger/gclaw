/**
 * 人脸验证 API 调用封装
 */
import type {
  FaceVerifyCheckResult,
  FaceVerifyInitRequest,
  FaceVerifyInitResponse,
  FaceVerifyResultResponse,
  FaceVerifyConfigItem,
} from '../types/face-verify'

const BASE_URL = '/api/face-verify'

/** 通用请求方法 */
async function request<T>(url: string, options?: RequestInit): Promise<T> {
  const response = await fetch(url, {
    headers: { 'Content-Type': 'application/json' },
    ...options,
  })

  if (!response.ok) {
    const error = await response.json().catch(() => ({ error: '请求失败' }))
    throw new Error(error.error || `HTTP ${response.status}`)
  }

  return response.json()
}

/**
 * 检查操作是否需要人脸验证
 */
export function checkFaceVerify(operationType: string): Promise<FaceVerifyCheckResult> {
  return request<FaceVerifyCheckResult>(
    `${BASE_URL}/check?operationType=${encodeURIComponent(operationType)}`
  )
}

/**
 * 发起人脸验证
 */
export function initiateFaceVerify(data: FaceVerifyInitRequest): Promise<FaceVerifyInitResponse> {
  return request<FaceVerifyInitResponse>(BASE_URL + '/initiate', {
    method: 'POST',
    body: JSON.stringify(data),
  })
}

/**
 * 轮询验证结果
 */
export function getFaceVerifyResult(verificationId: string): Promise<FaceVerifyResultResponse> {
  return request<FaceVerifyResultResponse>(
    `${BASE_URL}/result?verificationId=${encodeURIComponent(verificationId)}`
  )
}

/**
 * 获取所有配置 (管理)
 */
export function getFaceVerifyConfigs(): Promise<FaceVerifyConfigItem[]> {
  return request<FaceVerifyConfigItem[]>(BASE_URL + '/configs')
}

/**
 * 更新配置 (管理)
 */
export function updateFaceVerifyConfig(config: Partial<FaceVerifyConfigItem>): Promise<void> {
  return request<void>(BASE_URL + '/config', {
    method: 'PUT',
    body: JSON.stringify(config),
  })
}
