<template>
  <Teleport to="body">
    <div v-if="visible" class="face-verify-overlay" @click.self="handleOverlayClick">
      <div class="face-verify-dialog">
        <!-- 头部 -->
        <div class="face-verify-header">
          <h3 class="face-verify-title">
            {{ titleText }}
          </h3>
          <button
            v-if="closable"
            class="face-verify-close"
            @click="handleClose"
          >
            ✕
          </button>
        </div>

        <!-- 内容区 -->
        <div class="face-verify-content">
          <!-- 加载中 -->
          <div v-if="status === 'loading'" class="face-verify-loading">
            <div class="face-verify-spinner" />
            <p>正在发起人脸验证...</p>
          </div>

          <!-- 刷脸 iframe -->
          <iframe
            v-if="status === 'in_progress' || status === 'polling'"
            :src="authUrl"
            class="face-verify-iframe"
            allow="camera; microphone"
            sandbox="allow-scripts allow-same-origin allow-forms allow-popups"
          />

          <!-- 轮询中 -->
          <div v-if="status === 'polling' && !authUrl" class="face-verify-loading">
            <div class="face-verify-spinner" />
            <p>正在验证中，请稍候...</p>
          </div>

          <!-- 验证通过 -->
          <div v-if="status === 'passed'" class="face-verify-success">
            <div class="face-verify-icon">✓</div>
            <p>人脸验证通过</p>
            <p class="face-verify-sub">正在提交操作...</p>
          </div>

          <!-- 验证失败 -->
          <div v-if="status === 'failed' || status === 'error'" class="face-verify-fail">
            <div class="face-verify-icon fail">✕</div>
            <p>人脸验证失败</p>
            <p class="face-verify-sub">{{ errorMessage || '请重新尝试' }}</p>
            <button class="face-verify-retry" @click="handleRetry">重新验证</button>
          </div>

          <!-- 超时 -->
          <div v-if="status === 'expired'" class="face-verify-fail">
            <div class="face-verify-icon fail">⏱</div>
            <p>验证已超时</p>
            <p class="face-verify-sub">{{ errorMessage }}</p>
            <button class="face-verify-retry" @click="handleRetry">重新验证</button>
          </div>
        </div>
      </div>
    </div>
  </Teleport>
</template>

<script setup lang="ts">
import { computed } from 'vue'
import type { VerifyStatus } from '../../types/face-verify'

const props = defineProps<{
  visible: boolean
  status: VerifyStatus
  authUrl: string | null
  errorMessage: string | null
}>()

const emit = defineEmits<{
  cancel: []
  retry: []
}>()

const titleText = computed(() => {
  const titles: Record<string, string> = {
    idle: '人脸验证',
    checking: '检查验证要求...',
    loading: '正在发起验证...',
    in_progress: '请完成人脸验证',
    polling: '正在验证...',
    passed: '验证通过',
    failed: '验证失败',
    expired: '验证超时',
    error: '验证异常',
  }
  return titles[props.status] || '人脸验证'
})

const closable = computed(() => {
  return ['passed', 'failed', 'expired', 'error', 'idle'].includes(props.status)
})

function handleClose() {
  emit('cancel')
}

function handleOverlayClick() {
  if (closable.value) {
    emit('cancel')
  }
}

function handleRetry() {
  emit('retry')
}
</script>

<style scoped>
.face-verify-overlay {
  position: fixed;
  inset: 0;
  background: rgba(0, 0, 0, 0.6);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 9999;
}

.face-verify-dialog {
  background: #fff;
  border-radius: 12px;
  width: 90vw;
  max-width: 480px;
  max-height: 85vh;
  display: flex;
  flex-direction: column;
  overflow: hidden;
  box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
}

.face-verify-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 16px 20px;
  border-bottom: 1px solid #eee;
}

.face-verify-title {
  margin: 0;
  font-size: 18px;
  font-weight: 600;
  color: #333;
}

.face-verify-close {
  background: none;
  border: none;
  font-size: 18px;
  color: #999;
  cursor: pointer;
  padding: 4px 8px;
  border-radius: 4px;
}

.face-verify-close:hover {
  background: #f5f5f5;
  color: #333;
}

.face-verify-content {
  flex: 1;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 40px 20px;
  min-height: 300px;
}

.face-verify-loading {
  text-align: center;
  color: #666;
}

.face-verify-spinner {
  width: 40px;
  height: 40px;
  border: 3px solid #e0e0e0;
  border-top-color: #4a90d9;
  border-radius: 50%;
  animation: spin 0.8s linear infinite;
  margin: 0 auto 16px;
}

@keyframes spin {
  to { transform: rotate(360deg); }
}

.face-verify-iframe {
  width: 100%;
  height: 450px;
  border: none;
}

.face-verify-success {
  text-align: center;
  color: #52c41a;
}

.face-verify-icon {
  width: 64px;
  height: 64px;
  border-radius: 50%;
  background: #f6ffed;
  border: 2px solid #52c41a;
  color: #52c41a;
  font-size: 32px;
  display: flex;
  align-items: center;
  justify-content: center;
  margin: 0 auto 16px;
}

.face-verify-icon.fail {
  background: #fff2f0;
  border-color: #ff4d4f;
  color: #ff4d4f;
}

.face-verify-fail {
  text-align: center;
  color: #ff4d4f;
}

.face-verify-sub {
  color: #999;
  font-size: 14px;
  margin-top: 8px;
}

.face-verify-retry {
  margin-top: 20px;
  padding: 8px 24px;
  background: #4a90d9;
  color: #fff;
  border: none;
  border-radius: 6px;
  cursor: pointer;
  font-size: 14px;
}

.face-verify-retry:hover {
  background: #3a7bc8;
}

/* 移动端适配 */
@media (max-width: 640px) {
  .face-verify-dialog {
    width: 100vw;
    max-width: 100%;
    height: 100vh;
    max-height: 100vh;
    border-radius: 0;
  }

  .face-verify-iframe {
    height: 100%;
  }
}
</style>
