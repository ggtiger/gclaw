<template>
  <div class="face-verify-status" :class="statusClass">
    <span class="face-verify-dot" />
    <span class="face-verify-label">{{ label }}</span>
  </div>
</template>

<script setup lang="ts">
import { computed } from 'vue'
import type { VerifyStatus } from '../../types/face-verify'

const props = defineProps<{
  status: VerifyStatus
}>()

const label = computed(() => {
  const labels: Record<string, string> = {
    idle: '',
    checking: '检查中...',
    loading: '加载中...',
    in_progress: '刷脸验证中',
    polling: '验证中...',
    passed: '验证通过',
    failed: '验证失败',
    expired: '验证超时',
    error: '验证异常',
  }
  return labels[props.status] || ''
})

const statusClass = computed(() => {
  if (props.status === 'passed') return 'status-success'
  if (props.status === 'failed' || props.status === 'error' || props.status === 'expired') return 'status-error'
  if (props.status === 'in_progress' || props.status === 'polling') return 'status-active'
  return 'status-idle'
})
</script>

<style scoped>
.face-verify-status {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  font-size: 13px;
  padding: 2px 10px;
  border-radius: 12px;
}

.face-verify-dot {
  width: 6px;
  height: 6px;
  border-radius: 50%;
}

.status-idle {
  color: #999;
  background: #f5f5f5;
}
.status-idle .face-verify-dot {
  background: #ccc;
}

.status-active {
  color: #4a90d9;
  background: #e6f7ff;
}
.status-active .face-verify-dot {
  background: #4a90d9;
  animation: pulse 1.5s ease-in-out infinite;
}

.status-success {
  color: #52c41a;
  background: #f6ffed;
}
.status-success .face-verify-dot {
  background: #52c41a;
}

.status-error {
  color: #ff4d4f;
  background: #fff2f0;
}
.status-error .face-verify-dot {
  background: #ff4d4f;
}

@keyframes pulse {
  0%, 100% { opacity: 1; }
  50% { opacity: 0.4; }
}
</style>
