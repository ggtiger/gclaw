/**
 * 人脸验证相关类型定义
 */

/** 验证状态 */
export type VerifyStatus = 'idle' | 'checking' | 'loading' | 'in_progress' | 'polling' | 'passed' | 'failed' | 'expired' | 'error'

/** 检查是否需要验证 - 响应 */
export interface FaceVerifyCheckResult {
  operationType: string
  required: boolean
  operationName?: string
  faceauthMode?: string
  maxRetry?: number
}

/** 发起验证 - 请求 */
export interface FaceVerifyInitRequest {
  operationType: string
  businessId?: string
  businessNo?: string
  userId: string
  userName: string
  idNo: string
}

/** 发起验证 - 响应 */
export interface FaceVerifyInitResponse {
  verificationId: string
  authUrl: string
  expireAt: string
}

/** 验证结果 - 响应 */
export interface FaceVerifyResultResponse {
  verificationId: string
  status: 'pending' | 'in_progress' | 'passed' | 'failed' | 'expired'
  verificationToken?: string
  tokenExpireAt?: string
  errorMessage?: string
}

/** 验证配置 */
export interface FaceVerifyConfigItem {
  id: number
  operationType: string
  operationName: string
  enabled: boolean
  faceauthMode: string
  timeoutSeconds: number
  maxRetry: number
  description?: string
}

/** useFaceVerify Composable 选项 */
export interface UseFaceVerifyOptions {
  operationType: string
  onSuccess?: (token: string) => void
  onFail?: (error: string) => void
}

/** useFaceVerify Composable 返回值 */
export interface UseFaceVerifyReturn {
  visible: Ref<boolean>
  status: Ref<VerifyStatus>
  authUrl: Ref<string | null>
  errorMessage: Ref<string | null>
  submitWithVerify: (submitFn: (verificationToken?: string) => Promise<void>) => Promise<void>
  cancelVerify: () => void
}
