-- =====================================================
-- 人脸验证功能 - 数据库表
-- =====================================================

-- 操作验证配置表
CREATE TABLE IF NOT EXISTS face_verify_config (
    id              BIGINT PRIMARY KEY AUTO_INCREMENT,
    operation_type  VARCHAR(64) NOT NULL UNIQUE COMMENT '操作类型编码',
    operation_name  VARCHAR(128) NOT NULL COMMENT '操作显示名称',
    enabled         TINYINT(1) DEFAULT 1 COMMENT '是否启用人脸验证',
    faceauth_mode   VARCHAR(32) DEFAULT 'TENCENT' COMMENT '刷脸方式: ZHIMACREDIT/TENCENT/ESIGN',
    timeout_seconds INT DEFAULT 180 COMMENT '验证超时秒数',
    max_retry       INT DEFAULT 3 COMMENT '最大重试次数',
    description     VARCHAR(512) COMMENT '说明',
    is_deleted      TINYINT(1) DEFAULT 0 COMMENT '逻辑删除',
    created_at      DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at      DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) COMMENT '人脸验证操作配置表';

-- 验证记录表
CREATE TABLE IF NOT EXISTS face_verify_record (
    id                  BIGINT PRIMARY KEY AUTO_INCREMENT,
    verification_id     VARCHAR(64) NOT NULL UNIQUE COMMENT '验证唯一ID',
    flow_id             VARCHAR(64) COMMENT 'BestSign流程ID',
    operation_type      VARCHAR(64) NOT NULL COMMENT '关联操作类型',
    business_id         VARCHAR(64) COMMENT '业务ID',
    business_no         VARCHAR(128) COMMENT '业务单号',
    user_id             VARCHAR(64) NOT NULL COMMENT '操作用户ID',
    user_name           VARCHAR(64) NOT NULL COMMENT '用户姓名',
    id_no               VARCHAR(256) NOT NULL COMMENT '证件号(AES加密)',
    status              VARCHAR(32) NOT NULL DEFAULT 'pending' COMMENT 'pending/in_progress/passed/failed/expired',
    verification_token  VARCHAR(512) COMMENT '验证通过后签发的token',
    token_expire_at     DATETIME COMMENT 'token过期时间',
    token_consumed      TINYINT(1) DEFAULT 0 COMMENT 'token是否已消费(一次性)',
    error_message       VARCHAR(512) COMMENT '失败原因',
    is_deleted          TINYINT(1) DEFAULT 0 COMMENT '逻辑删除',
    created_at          DATETIME DEFAULT CURRENT_TIMESTAMP,
    completed_at        DATETIME COMMENT '完成时间',
    INDEX idx_user_id (user_id),
    INDEX idx_flow_id (flow_id),
    INDEX idx_status (status),
    INDEX idx_business_id (business_id),
    INDEX idx_business_no (business_no)
) COMMENT '人脸验证记录表';

-- =====================================================
-- 初始化配置数据
-- =====================================================
INSERT INTO face_verify_config (operation_type, operation_name, enabled, description)
VALUES
    ('contract_sign', '合同签署', 1, '合同签署前需进行人脸验证'),
    ('contract_approval', '合同审批', 1, '合同审批确认前需进行人脸验证'),
    ('payment_confirm', '付款确认', 1, '付款操作前需进行人脸验证'),
    ('seal_apply', '用印申请', 0, '用印申请前需进行人脸验证（默认关闭）');
